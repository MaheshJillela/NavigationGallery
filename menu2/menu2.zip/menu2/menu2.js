$('nav .button').click(function(){
    $('nav .button span').toggleClass("rotate");
  });
    $('nav ul li .first').click(function(){
      $('nav ul li .first span').toggleClass("rotate");
    });
    $('nav ul li .second').click(function(){
      $('nav ul li .second span').toggleClass("rotate");
    });